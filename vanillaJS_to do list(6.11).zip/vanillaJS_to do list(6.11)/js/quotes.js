const quotes = [
    {
        quote: "The way to get started is to quit talking and begin",
        clock: "Walt Disney",
    },
    {
        quote: "Life is what happens when you're busy making other",
        author: "John Lennon",
    },
    {
        quote: "The world is a book and those who do not travel read only",
        author: "Saint Augustine",
    },
    {
        quote: "We still do not know one-thousandth of one percent of what nature has revealed to us.",
        author: "Albert Einstein",
    },
    {
        quote: "You may delay, but time will not.",
        author: "Benjamin Franklin",
    },
    {
        quote: "Men will fight long and hard for a bit of colored ribbon.",
        author: "Napoleon Bonaparte",
    },
    {
        quote: "The future depends on what we do in the present.",
        author: "Mahatma Gandhi",
    },
    {
        quote: "Leadership and learning are indispensable to each other.",
        author: "John F. Kennedy",
    },
    {
        quote: "Having been poor is no shame, but being ashamed of it, is.",
        author: "Benjamin Franklin",
    },
    {
        quote: "Our greatest glory is not in never falling, but in rising every time we fall.",
        author: "Confucius",
    },
];


const quote = document.querySelector("#quote span:first-child");
const author = document.querySelector("#quote span:last-child");
const todaysQuote = quotes[Math.floor(Math.random() * quotes.length)];

quote.innerText = todaysQuote.quote;
author.innerText = todaysQuote.author;
